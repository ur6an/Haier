      document.addEventListener("DOMContentLoaded", function() {
        const url = new URL (document.URL)
        var adds = false
        if (url.pathname == '/parameters') {
                adds = true
        }
	console.log(adds)
	      // Nawiązujemy połączenie z serwerem
        const socket = io();
        // Nasłuchujemy na zdarzenie 'data_update'
        socket.on('data_update', function(msg) {
          //console.log("Otrzymano wiadomość:", msg.data);
	  switch(Object.keys(msg)[0]) {
	    case "twitwo":
	    	$("#two").text(msg.twitwo[1])
		twitwo=msg.twitwo
		break;
	    case "compinfo":
		$("#fact").text(msg.compinfo[0])
		compinfo = msg.compinfo
		updateDeltaVisibility();
		break;
	    case "pump":
		$("#pump").text(msg.pump.toLowerCase())
		$("#pump").attr("data-i18n", msg.pump.toLowerCase());
		break;
	    case "threeway":
		// 3-way valve status (also used as DEFROST indicator)
		const twRaw = (msg.threeway !== undefined && msg.threeway !== null) ? String(msg.threeway) : "";
		const twLower = twRaw.toLowerCase();
		$("#threeway").text(twLower)
		$("#threeway").attr("data-i18n", twLower);
		// Subtle blue pulse during DEFROST
		if (twRaw.toUpperCase() === "DEFROST") $("#threeway").addClass("defrost-pulse");
		else $("#threeway").removeClass("defrost-pulse");
		lastThreeway = twRaw;
		updateDeltaVisibility();
		break;
	    case "archerror":
		$("#archerror").text(msg.archerror)
		break;
	    case "dtquiet":
		$("#deltatempquiet").text(parseFloat(msg.dtquiet).toFixed(1));
		break;
	    case "dtturbo":
		$("#deltatempturbo").text(parseFloat(msg.dtturbo).toFixed(1));
		break;
	    case "dtflimit":
		$("#deltatempflimit").text(parseFloat(msg.dtflimit).toFixed(1));
		break;
	    case "aoodt":
        	$("#antionoffdeltatime").text(parseFloat(msg.aoodt).toFixed(1));
		break;
	    case "delta":
		$("#delta").text(msg.delta);
		break;
	    case "flimiton":
		$("#flimiton").text(msg.flimiton)
		$("#flimitchange").val(msg.flimiton)
		switch (msg.flimiton) {
		    case "0":
			$("#flrelay").text("off");
			$("#flrelay").attr("data-i18n", "off");
			setFreqLimitActive(msg.flimiton);
				break;
		    case "1":
			$("#flrelay").text("on");
			$("#flrelay").attr("data-i18n", "on");
			break;
		}
		break;
	    case "tank":
		$("#ttemp").text(msg.tank)
		break;
	    case "hcurve":
		$("#hcurve").text(msg.hcurve)
		break;
	    case "dhw":
                $("#dhwsetpoint").text(msg.dhw)
                dhwsetpoint = msg.dhw
                $("#dhwtempval").val(msg.dhw)
                break;
	    case "setpoint":
		$("#setpoint").text(msg.setpoint)
		$("#intempval").val(msg.setpoint)
		temp = msg.setpoint
		break;
	    case "intemp":
		$("#intemp").text(msg.intemp);
		break;
	    case "outtemp":
		$("#outtemp").text(parseFloat(msg.outtemp).toFixed(1));
		break;
	    case "humid":
		$("#humid").text(parseFloat(msg.humid).toFixed(1))
		break;
	    case "ltemp":
		$("#ltemp").text(msg.ltemp)
		break;
	    case "antionoff":
		if(msg.antionoff == "1") {
		    $("#presetdiv").hide();
		    $("#antionoffdiv").show();
		}
		break;
	    case "mode":
		$("#presetchange").val(msg.mode)
				$("#mode").text(msg.mode)
						setActiveMode(msg.mode);

		break;
	    case "presetquiet":
		$("#presetquiet").text(msg.presetquiet);
		break;
	    case "presetturbo":
		$("#presetturbo").text(msg.presetturbo);
		break;
	    case "presetch":
		if(msg.presetch == "manual") {
		    $("#presetchange").show()
		    $("#preset").text(" Auto")
		} else if ( msg.presetch == "auto") {
		    $("#presetauto").show();
		    $("#preset").text("Manual")
		}
		break;
	    case "fflimit":
		if(msg.fflimit == "manual") {
		    $("#flimit").text("Manual")
		    $("#flimitchange").show()
		} else if (msg.fflimit == "auto"){
		    $("#flimitauto").show()
		    $("#flimit").text("Auto")
		}
		break;
	    case "heatingcurve":
		if(msg.heatingcurve == "directly" ) {
		    minch=25
		    maxch=55
		} else {
		    minch=12
		    maxch=30
		}
		break;
	  }
	if (msg.threeway !== undefined && msg.threeway !== null) { lastThreeway = msg.threeway; }
	updateDeltaVisibility();

	switch(msg.threeway) {
                case "CH":
                        if ( compinfo[0] > 0 ) {
                                updateFireStatus("ch","firestatus.heating");
                                updateFireStatus("dhw","firestatus.idle");
                        } else {
                                updateFireStatus("ch","firestatus.idle");
                                updateFireStatus("dhw","firestatus.idle");
                        }
        break;
                case "DHW":
                        if ( compinfo[0] > 0 ) {
                                updateFireStatus("dhw","firestatus.heating");
                                updateFireStatus("ch","firestatus.idle");
                        } else {
                                updateFireStatus("dhw","firestatus.idle");
                                updateFireStatus("ch","firestatus.idle");
                        }
        break;
		    }
	switch(msg.pch) {
                    case "on":
                        if ($("#firestatus")[0].classList.contains("bi-snow") == true ) {
                                toggleCSSclasses($("#firestatus")[0], "bi-fire", "bi-snow")
                                $("#powerheat").val("pch");
                                $("#water-decrement-button").removeAttr('disabled');
                                $("#water-increment-button").removeAttr('disabled');
                        } else if ($("#firestatus")[0].classList.contains("bi-fire") == false) {
                                $("#firestatus")[0].classList.add("bi-fire");
                                $("#powerheat").val("pch");
                                $("#water-decrement-button").removeAttr('disabled');
                                $("#water-increment-button").removeAttr('disabled');
                        }
                        break;
                    case "off":
                        if ($("#firestatus")[0].classList.contains("bi-fire") == true ) {
                                $("#firestatus")[0].classList.remove("bi-fire");
                                $("#powerheat").val("off");
                                $("#water-decrement-button").attr('disabled','disabled');
                                $("#water-increment-button").attr('disabled','disabled');
                        }
                        break;
                    default:
                }
                switch(msg.pcool) {
                    case "on":
                        if ($("#firestatus")[0].classList.contains("bi-fire") == true ) {
                                toggleCSSclasses($("#firestatus")[0], "bi-fire", "bi-snow")
                                $("#powerheat").val("pcool");
                                $("#water-decrement-button").removeAttr('disabled');
                                $("#water-increment-button").removeAttr('disabled');
                        } else if ($("#firestatus")[0].classList.contains("bi-fire") == false) {
                                $("#firestatus")[0].classList.add("bi-snow");
                                $("#powerheat").val("pcool");
                                $("#water-decrement-button").removeAttr('disabled');
                                $("#water-increment-button").removeAttr('disabled');
                        }
                        break;
                    case "off":
                        if ($("#firestatus")[0].classList.contains("bi-snow") == true ) {
                                $("#firestatus")[0].classList.remove("bi-snow");
                                $("#powerheat").val("off");
                                $("#water-decrement-button").attr('disabled','disabled');
                                $("#water-increment-button").attr('disabled','disabled');

                        }
                        break;
                    default:
                }
                switch(msg.pdhw) {
                    case "on":
                        if ($("#dhwstatus")[0].classList.contains("bi-droplet-fill") == false ) {
                                toggleCSSclasses($("#dhwstatus")[0], "bi-droplet-fill", "bi-power")
                                $("#powerdhw").val("on");
                                $("#dhw-decrement-button").removeAttr('disabled');
                                $("#dhw-increment-button").removeAttr('disabled');
                        }
                        break;
                    case "off":
                        if ($("#dhwstatus")[0].classList.contains("bi-droplet-fill") == true ) {
                                toggleCSSclasses($("#dhwstatus")[0], "bi-droplet-fill", "bi-power")
                                $("#powerdhw").val("off");
                                $("#dhw-decrement-button").attr('disabled','disabled');
                                $("#dhw-increment-button").attr('disabled','disabled');
                        } else {
                                $("#powerdhw").val("off");
                                $("#dhw-decrement-button").attr('disabled','disabled');
                                $("#dhw-increment-button").attr('disabled','disabled');
                        }
                        break;
                    default:
                }

	  console.log(msg)
        });
      });

  // ---- UI helpers: active mode highlight (Quiet/Eco/Turbo) + frequency limit label ----
  function setActiveMode(mode) {
    const ids = ["quiet", "eco", "turbo"];
    const names = { quiet: "Quiet", eco: "Eco", turbo: "Turbo" };

    // Remove highlight classes
    ids.forEach(id => { const el = $("#"+id); if (el.length) el.removeClass("mode-active"); });
    ids.forEach(id => { const el = $("#"+id+"-label"); if (el.length) el.removeClass("mode-active"); });

    // Reset any old HTML (<b><u>...) back to plain text
    for (const [id, label] of Object.entries(names)) {
      const el = $("#"+id); if (el.length) el.text(label);
      const lab = $("#"+id+"-label"); if (lab.length) lab.text(label);
    }

    // Highlight active one
    if (ids.includes(String(mode))) {
      const el = $("#"+mode); if (el.length) el.addClass("mode-active");
      const lab = $("#"+mode+"-label"); if (lab.length) lab.addClass("mode-active");
    }
  }

  function setFreqLimitActive(on) {
    const lab = $("#flimiton-label");
    if (!lab.length) return;
    if (String(on) === "1") lab.addClass("mode-active");
    else lab.removeClass("mode-active");
  }


// ---- UI helper: show Δt only when compressor works AND three-way valve is in CH ----
let lastThreeway = null;
function updateDeltaVisibility() {
  const deltaEl = $("#delta");
  if (!deltaEl.length) return; // element exists only on main dashboard (antionoff card)
  const compHz = (typeof compinfo !== "undefined" && compinfo && compinfo.length) ? Number(compinfo[0]) : 0;
  const tw = (lastThreeway !== null && lastThreeway !== undefined) ? String(lastThreeway).toUpperCase() : "";
  const shouldShow = (compHz > 0) && (tw === "CH");
  const wrap = deltaEl.closest("span"); // <span>Δt = <b id="delta">...</b> °C</span>
  if (wrap.length) wrap.toggle(shouldShow);
}  // -------------------------------------------------------------------------------

