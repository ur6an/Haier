// Navbar HPi service status (LED + tooltip)
// Polls backend /api/hpi_status and renders:
// - OK: blue diode
// - Error: blinking red diode
// - Unknown: grey
// Tooltip UX (per request):
// - click on the HPi pill -> show/hide tooltip
// - leaving the pill -> hide tooltip
// - no live content updates while tooltip is open (prevents disappearing on refresh)
//
// Extra UX (requested):
// - if an ERROR is detected (red blinking), the HPi pill becomes visible automatically

document.addEventListener("DOMContentLoaded", () => {
  const pill = document.getElementById("hpi-status-pill");
  const led = document.getElementById("hpi-status-led");
  if (!pill || !led) return;

  const OK_RX_AGE_S = 15; // consider pump comms stale after this

  // --- Tooltip (single instance, manual) ---
  let tipInst = null;
  let tipShown = false;
  let lastTipHtml = "HPi: sprawdzanie...";

  // When true, we keep the pill visible (used for ERROR auto-reveal)
  let forcedVisible = false;

  function setLed(state) {
    led.classList.remove("hpi-led-ok", "hpi-led-err", "hpi-led-unknown");
    if (state === "ok") led.classList.add("hpi-led-ok");
    else if (state === "err") led.classList.add("hpi-led-err");
    else led.classList.add("hpi-led-unknown");
  }

  function keepPillVisible() {
    pill.classList.add("hpi-reveal");
    window.clearTimeout(revealPill._t);
  }

  function updateVisibility() {
    // keep visible if:
    // - forcedVisible (ERROR)
    // - tooltip open (user is reading)
    if (forcedVisible || tipShown) {
      keepPillVisible();
    } else {
      pill.classList.remove("hpi-reveal");
    }
  }

  function revealPill(ms = 2500) {
    pill.classList.add("hpi-reveal");
    window.clearTimeout(revealPill._t);

    // If ERROR is active or tooltip is open, never auto-hide
    if (forcedVisible || tipShown) return;

    if (ms > 0) {
      revealPill._t = window.setTimeout(() => {
        if (!forcedVisible && !tipShown) pill.classList.remove("hpi-reveal");
      }, ms);
    }
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function toHtml(text) {
    return escapeHtml(text).replace(/\n/g, "<br>");
  }

  function ensureTooltip() {
    if (tipInst) return tipInst;
    if (!window.bootstrap || !bootstrap.Tooltip) return null;
    try {
      tipInst = new bootstrap.Tooltip(pill, {
        trigger: "manual",
        html: true,
        placement: "bottom",
        // Use a function so Bootstrap reads current content on each .show()
        title: () => lastTipHtml,
      });
      return tipInst;
    } catch (e) {
      return null;
    }
  }

  function setTooltipText(text) {
    // Always update stored content, but DO NOT push updates into an open tooltip.
    lastTipHtml = toHtml(text);
    if (!tipShown) {
      // keep attributes in sync for the next show()
      pill.setAttribute("data-bs-title", lastTipHtml);
      pill.setAttribute("data-bs-original-title", lastTipHtml);
    }
  }

  function showTooltip() {
    const inst = ensureTooltip();
    if (!inst) return;

    // Sync attributes right before show (Bootstrap may read them)
    pill.setAttribute("data-bs-title", lastTipHtml);
    pill.setAttribute("data-bs-original-title", lastTipHtml);

    // Keep pill visible while tooltip is open
    tipShown = true;
    updateVisibility();

    try {
      inst.show();
    } catch (e) {
      tipShown = false;
      updateVisibility();
    }
  }

  function hideTooltip() {
    if (!tipInst) {
      tipShown = false;
      updateVisibility();
      return;
    }
    try {
      tipInst.hide();
    } catch (e) {
      // ignore
    }
    tipShown = false;
    updateVisibility();

    // after hide we can safely apply current content for the next click
    pill.setAttribute("data-bs-title", lastTipHtml);
    pill.setAttribute("data-bs-original-title", lastTipHtml);
  }

  pill.addEventListener("click", (e) => {
    e.preventDefault();
    // Reveal briefly even if OK (nice on touch), but ERROR/tooltips will override auto-hide
    revealPill(3000);
    if (tipShown) hideTooltip();
    else showTooltip();
  });

  // Hide as soon as the cursor leaves the pill
  pill.addEventListener("mouseleave", () => {
    if (tipShown) hideTooltip();
  });

  // Hide on outside click (useful for touch)
  document.addEventListener("pointerdown", (e) => {
    if (!tipShown) return;
    if (!pill.contains(e.target)) hideTooltip();
  });

  // Hide on ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && tipShown) hideTooltip();
  });

  function fmtAge(age) {
    if (age === null || age === undefined) return "brak";
    const n = Number(age);
    if (!Number.isFinite(n)) return "brak";
    return n.toFixed(1) + " s";
  }

  function fmtBool(v) {
    if (v === null || v === undefined) return "—";
    return v ? "OK" : "ERR";
  }

  async function poll() {
    try {
      const r = await fetch("/api/hpi_status", { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();

      const dead = Number(j.dead ?? 0);
      const bgOk = !!(j.threads && j.threads.bg);
      const serialOk = !!(j.threads && j.threads.serial);
      const mqtt = (j.threads && j.threads.mqtt !== undefined) ? j.threads.mqtt : null;
      const mqttOk = (mqtt === null || mqtt === undefined) ? true : !!mqtt;

      const age = (j.pump_rx && j.pump_rx.age_s !== undefined) ? j.pump_rx.age_s : null;
      const block = (j.pump_rx && j.pump_rx.block) ? j.pump_rx.block : "—";
      const errTxt = (j.pump_rx && j.pump_rx.last_error) ? String(j.pump_rx.last_error).split("\n")[0] : "";

      const stale = (age !== null && age !== undefined && Number(age) > OK_RX_AGE_S);
      const isOk = (dead === 0) && bgOk && serialOk && mqttOk && !stale;

      setLed(isOk ? "ok" : "err");

      // Requested behavior: auto-show pill on ERROR
      forcedVisible = !isOk;
      updateVisibility();

      let tip = isOk ? "HPi: OK" : "HPi: BŁĄD";
      tip += `\n• Wątki: bg=${fmtBool(bgOk)}, Serial=${fmtBool(serialOk)}`;
      if (mqtt !== null && mqtt !== undefined) tip += `, mqtt=${fmtBool(!!mqtt)}`;
      tip += `\n• Odczyt: Ostatnia ramka ${block}, Wiek: ${fmtAge(age)}`;
      if (dead !== 0) tip += `\n• DEAD=${dead}`;
      if (!isOk && errTxt) tip += `\n• last_error: ${errTxt}`;

      setTooltipText(tip);
    } catch (e) {
      setLed("err");

      // Requested behavior: if backend is down, also auto-show pill
      forcedVisible = true;
      updateVisibility();

      setTooltipText("HPi: brak połączenia z backendem\n" + String(e));
    }
  }

  // Mobile hint: reveal pill briefly on touch
  pill.addEventListener("pointerdown", () => revealPill(3000));

  poll();
  window.setInterval(poll, 1500);
});
